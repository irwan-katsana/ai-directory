export interface Tool {
  id: string;
  name: string;
  description: string;
  url: string;
  isOnline?: boolean;
}